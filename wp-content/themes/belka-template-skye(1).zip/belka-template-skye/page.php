<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Belka_Template_Skye
 */

get_header();
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
.row {
    padding: 54px 0 0 0;
}
.container-fluid .content-area {padding: 45px;}
.container-fluid .side-area {
    background: #f7f7f7;
    padding: 43px 4px 30px 22px;
}
.container-fluid {
    padding-top: 74px;
}
h1.entry-title {
    padding: 0 0 7px 0;
    border-bottom: 4px double #e4e4e4;
    margin: 0 0 17px 0;
	font-family: "HelveticaNeueCyr-Roman", sans-serif;
}
h2.widget-title {
	font-family: "HelveticaNeueCyr-Roman", sans-serif;
}
ul li {font-family: "HelveticaNeueCyr-Roman", sans-serif;line-height: 25px;}
p {font-family: "HelveticaNeueCyr-Roman", sans-serif;}
ul#recentcomments li span {
	font-family: "HelveticaNeueCyr-Roman", sans-serif;
}
aside#secondary section {
    margin: 13px 0 13px 0;
    border-bottom: 2px solid #efefef;
    padding: 5px;
}
</style>
  
<div class="container-fluid">
	<div class="row">
	<div id="primary" class="col-sm-8 content-area">
		<main id="main" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->


<div id="primary" class="col-sm-4 side-area" >
			<aside id="secondary" class="widget-area">
				<?php get_sidebar(); ?>
			</aside><!-- #secondary -->
		</div>
</div>
</div>

<?php

get_footer();
