$(function () {

  let usd = $('.select-button');
  let $dropdown = $('#main-select-dropdown');

  usd.on('click', function () {

    $(this).toggleClass('select-active');

    $dropdown.toggleClass('dropdown-active');
  });

  let $dropel = $('#main-select-dropdown li span');

  $dropel.click(function () {

    let $showSelected = $('#selected-val');

    $showSelected.text($(this)[0].innerText);

    $dropdown.removeClass('dropdown-active');
    usd.removeClass('select-active');
  })

  $(document).click(function (e) {

    if ( !usd.is(e.target) && usd.has(e.target).length === 0 ) {

      $dropdown.removeClass('dropdown-active');
      usd.removeClass('select-active');
    }
  });
});