<?php
$logo = carbon_get_theme_option('header_logo');
?>

<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="profile" href="https://gmpg.org/xfn/11">

  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header>
  <div class="header-container">
    <div class="header-container-inner container">
      <?php if ($logo): ?>
      <div class="logo">
        <a href="#home"><img src="<?php echo $logo ?>" alt="Logo"></a>
      </div>
      <?php endif; ?>
      <nav class="navbar-container">
        <?php
        wp_nav_menu([
            'theme_location' => 'top_first',
            'container' => null,
            'items_wrap' => '<ul class="first-nav d-flex" id="first-nav">%3$s</ul>'
        ]);
        ?>
        <?php
        wp_nav_menu([
            'theme_location' => 'top_second',
            'container' => null,
            'items_wrap' => '<ul class="second-nav d-flex" id="second-nav">%3$s</ul>'
        ]);
        ?>
        <ul id="dropdown-menu" class="hidden-nav" style="display: none !important;">

        </ul>
      </nav>
      <a id="btn-show" href="#" class="menu-btn">
        <span></span>
      </a>
    </div>
  </div>
</header>